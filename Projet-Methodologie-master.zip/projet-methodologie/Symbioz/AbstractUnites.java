public abstract class AbstractUnites
{

	/**
	 *	Cette méthode permet de tester si une zone contient bien 12 Zerb.
	 *
	 *	@param countZerb
	 *			Le nombre de Zerb dans la zone.
	 *	@param zone
	 *			La zone où se trouvent les Zerb.
	 */
	public boolean ifSymbioz(int countZherb, Case[] zone)
	{	
		// COMPLETER METHODE
		
		// This method must return a result of type boolean
		return true;
	}
	
}