public class Crapit
{
	private static final int VALEUR_CRAPIT = 3;

	public Crapit()
	{

	}

	/**
	 *	Cette méthode permet de retourner la valeur d'un Crapit par rapport à son coût de placement. 
	 *
	 *	@return
	 *			La valeur d'un Crapit.
	 */
	public static int getValueOfCrapit()
	{
		return Crapit.VALEUR_CRAPIT;
	}
	
}