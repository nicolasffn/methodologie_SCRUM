#!/bin/bash

#compilation du jeu:

rm *.class
javac *.java
java Main