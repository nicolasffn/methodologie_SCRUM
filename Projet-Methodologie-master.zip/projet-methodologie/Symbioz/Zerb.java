public class Zerb
{
	private static final int VALEUR_ZERB = 1;

	public Zerb()
	{

	}

	/**
	 *	Cette méthode permet de retourner la valeur d'un Zerb par rapport à son coût de placement. 
	 *
	 *	@return
	 *			La valeur d'un Zerb.
	 */
	public static int getValueOfZerb()
	{
		return Zerb.VALEUR_ZERB;
	}
	
}