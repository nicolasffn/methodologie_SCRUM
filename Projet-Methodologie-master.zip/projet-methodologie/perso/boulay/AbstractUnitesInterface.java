public interface AbstractUnitesInterface
{

	/**
	 *	Cette méthode permet de tester si une zone contient bien 12 Zerb.
	 *
	 *	@param countZerb
	 *			Le nombre de Zerb dans la zone.
	 *	@param zone
	 *			La zone où se trouvent les Zerb.
	 */
	public boolean ifSymbioz(int countZherb, Case[] zone);
	
}