import java.util.Scanner;

public class StartGame
{
	private int nbrJoueurs;	
	private Joueur joueur[] = new Joueur[4];

	public StartGame()
	{
		System.out.println("============================================================");
		System.out.println("===================== LANCEMENT DU JEU =====================");
		System.out.println("============================================================");
		System.out.println("                             --                             ");
		System.out.println("============================================================");
		System.out.println("===================== CREATION JOUEURS =====================");
		System.out.println("============================================================");
		System.out.println("                             --                             ");
		System.out.println("");
		Scanner sc = new Scanner(System.in);
		System.out.print("** Combien de joueurs vont jouer ? [2-4] : ");
		String nbrJoueurs = sc.nextLine();
		try 
		{
			this.nbrJoueurs = Integer.parseInt(nbrJoueurs);
			if(this.nbrJoueurs > 4) {
				System.err.println("Il ne peux pas y avoir plus de 4 joueurs !");
				System.exit(1);
			}
			System.out.println("                             --                             ");
			System.out.println("");

			for(int count = 0; count < this.nbrJoueurs; count++)
			{
				System.out.print("** Entrez le pseudo du joueur " + (count + 1) + " : ");
				String pseudoJoueur = sc.nextLine();
				int idJoueur = count+1;
				joueur[count] = new Joueur(pseudoJoueur, idJoueur);
			}
			sc.close();
//			System.out.println(joueur[1].getNbPointsRestants());
//			joueur[1].testEnleve1();
//			System.out.println(joueur[1].getNbPointsRestants());
//			joueur[1].testEnleve1();
//			joueur[1].testEnleve1();
//			joueur[1].testEnleve1();
//			System.out.println(joueur[2].getNbPointsRestants());
//			System.out.println(joueur[3].getNbPointsRestants());
//			System.out.println(joueur[1].getNbPointsRestants());
		}
		catch(NumberFormatException e)
		{
			System.out.println("                             --                             ");
			System.out.println("========================= [ERREUR] =========================");
			System.out.println("Merci de bien vouloir entrer un nombre de joueur compris entre 2 et 4.");
		}
		finally
		{
			sc.close();
		}

	}
}