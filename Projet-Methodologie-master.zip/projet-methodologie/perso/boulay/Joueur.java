public class Joueur
{
	private String nomJoueur;
	private int idJoueur;
	
	private int nbPointsJoueurs = 10;
	
	public Joueur(String nomJoueur, int id)
	{
		this.nomJoueur = nomJoueur;
		this.idJoueur = id;
		
		System.out.println("Salut " + this.nomJoueur + "#" + this.idJoueur + " !");
	}
	
	/**
	 *	Cette méthode permet de retourner le nombre total des points qu'ils restent d'un certain joueur. 
	 *	
	 *	@param id
	 *			L'id du joueur.
	 *	@return
	 *			Les points restants qu'ils restent pour un joueur.
	 */
	public int getNbPointsRestants() {
		return this.nbPointsJoueurs;
	}
	
	/**
	 *	METHODE TESTTTTTTTTTTTTT
	 */
	public int testEnleve1() {
		return this.nbPointsJoueurs--;
	}
}