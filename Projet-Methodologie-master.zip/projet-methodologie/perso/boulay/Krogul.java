public class Krogul
{
	private static final int VALEUR_KROGUL = 5;
	private static final int ID_KROGUL = 3;

	public Krogul()
	{

	}

	/**
	 *	Cette méthode permet de retourner la valeur d'un Krogul par rapport à son coût de placement. 
	 *
	 *	@return
	 *			La valeur d'un Krogul.
	 */
	public int getValueOfKrogul()
	{
		return this.VALEUR_KROGUL;
	}

	/**
	 *	Cette méthode permet de retourner l'id d'un Krogul.
	 *
	 *	@return
	 *			L'id d'un Krogul.
	 */
	public int getIdOfKrogul()
	{
		return this.ID_KROGUL;
	}

}