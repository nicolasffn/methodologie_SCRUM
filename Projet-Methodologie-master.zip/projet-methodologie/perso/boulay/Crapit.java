public class Crapit
{
	private static final int VALEUR_CRAPIT = 3;
	private static final int ID_CRAPIT = 2;

	public Crapit()
	{

	}

	/**
	 *	Cette méthode permet de retourner la valeur d'un Crapit par rapport à son coût de placement. 
	 *
	 *	@return
	 *			La valeur d'un Crapit.
	 */
	public int getValueOfCrapit()
	{
		return this.VALEUR_CRAPIT;
	}

	/**
	 *	Cette méthode permet de retourner l'id d'un Crapit.
	 *
	 *	@return
	 *			L'id d'un Crapit.
	 */
	public int getIdOfCrapit()
	{
		return this.ID_CRAPIT;
	}

}