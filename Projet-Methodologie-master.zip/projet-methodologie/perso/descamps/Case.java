public class Case
{	
	private String nom;
	private Zerb[] zerbs;
	private Crapit[] crapits;
	private Krogul[] kroguls;
	private ArrayList<Case> casesAdjacentes;

	@Override
	public abstract Case(int nbJoueurs, String nomCase)
	{
		this.zerbs = new Zerb[nbJoueurs];
		this.crapits = new Crapit[nbJoueurs];
		this.kroguls = new Krogul[nbJoueurs];
		this.casesAdjacentes = new ArrayList<Case>();

		this.nom = nomCase;

		for(int i = 0; i < nbJoueurs; i++)
		{
			this.zerbs[i] = 0;
			this.crapits[i] = 0;
			this.kroguls[i] = 0;
		}
	}

	public abstract addCaseAdjacente(Case c)
	{
		this.casesAdjacentes.add(c);
	}
}