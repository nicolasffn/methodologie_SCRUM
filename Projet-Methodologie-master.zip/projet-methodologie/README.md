# Projet-Methodologie

-----

[ Une petite description du projet ]

## Auteurs

* **Loïc BERNARD** _alias_ [@bernardl](https://dwarves.iut-fbleau.fr/git/bernardl)
* **Quentin BOULAY** _alias_ [@boulay](https://dwarves.iut-fbleau.fr/git/boulay)
* **Antoine DESCAMPS** _alias_ [@descamps](https://dwarves.iut-fbleau.fr/git/descamps)
* **Nicolas FAFIN** _alias_ [@fafin](https://dwarves.iut-fbleau.fr/git/fafin)
* **Noah LACASTE** _alias_ [@lacaste](https://dwarves.iut-fbleau.fr/git/lacaste)
* **Sylvain THOR** _alias_ [@thor](https://dwarves.iut-fbleau.fr/git/thor)

## Scrum Master

C'est le membre du groupe qui a minima va lire le document de 20 pages expliquant la méthode scrum et essayer de la digérer pour faciliter sa mise en oeuvre par l'équipe.
        
- Antoine DESCAMPS

## Product Owner

Le product owner sera responsable de gérer avec la client, le product backlog.
Au sein d’une équipe Scrum, le Product Owner fait le lien entre la partie métier et la partie technique du projet.
        
- Nicolas FAFIN

## Pour commencer

...