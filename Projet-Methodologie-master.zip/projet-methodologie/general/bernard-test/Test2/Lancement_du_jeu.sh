#!/bin/bash

#Ce place dans le bon repertoire:



#compilation du jeu:

javac *.java
