/**
 * 
 *
 */
public class Jeu
{
	/**
	 * <b>Jeu</b>
	 * 
	 */
	public Jeu(int nbrJoueurs, Joueur tabJoueur[])
	{
		System.out.println("============================================================");
		System.out.println("===================== LANCEMENT DU JEU =====================");
		System.out.println("============================================================");
		System.out.println("                             --                             ");
		System.out.println("");
		
		System.out.println("========================== PHASE1 ==========================");
		System.out.println("");

		System.out.println("** [JOUEUR]" + tabJoueur[0].getNomJoueur() + ", il te reste " + tabJoueur[0].getPointsActionRestants() + " point(s) d'actions !");
		System.out.println("** " + tabJoueur[0].getNomJoueur() + " place 2 Zerbs.");
		tabJoueur[0].addZerb(2);
		System.out.println("");
		System.out.println("** [JOUEUR]" + tabJoueur[0].getNomJoueur() + ", il te reste " + tabJoueur[0].getPointsActionRestants() + " point(s) d'actions !");
		System.out.println("** " + tabJoueur[0].getNomJoueur() + " place 1 Crapit.");
		tabJoueur[0].addCrapit(1);
		System.out.println("");
		System.out.println("** [JOUEUR]" + tabJoueur[0].getNomJoueur() + ", il te reste " + tabJoueur[0].getPointsActionRestants() + " point(s) d'actions !");
		System.out.println("** " + tabJoueur[0].getNomJoueur() + " place 1 Krogul.");
		tabJoueur[0].addKrogul(1);
		System.out.println("");
		System.out.println("** [JOUEUR]" + tabJoueur[0].getNomJoueur() + ", il te reste " + tabJoueur[0].getPointsActionRestants() + " point(s) d'actions !");
		System.out.println("");
		System.out.println("                             --                             ");

//		for(int i = 0; i < nbrJoueurs; i++)
//		{
//			String nomJoueur = tabJoueur[i].getPseudoJoueur();
//			int ptsRestants = tabJoueur[i].getNbPointsRestants();
//			
//			for(int j = ptsRestants; j > 0;) {
//				System.out.println("** " + nomJoueur + ", il te reste " + tabJoueur[i].getNbPointsRestants() + " points d'actions !");
//
//				System.out.print(nomJoueur + "place 2 Zerbs");
//				tabJoueur[i].addZerb(tabJoueur);
//				tabJoueur[i].addZerb(tabJoueur);
//				
//				System.out.println("");
//			
//			}
//		}
		
		System.out.println("========================== PHASE2 ==========================");
		System.out.println("");
		
		System.out.println("========================== PHASE3 ==========================");
		System.out.println("");
		
		System.out.println("========================== PHASE4 ==========================");
		System.out.println("");
		
	}
	
}
