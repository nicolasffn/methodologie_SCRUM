/**
 * 
 *
 */
public class Zerb
{
	private static final int VALEUR_ZERB = 1;
	private static final int ID_ZERB = 1;

	public Zerb()
	{

	}

	/**
	 *	Cette méthode permet de retourner la valeur d'un Zerb par rapport à son coût de placement. 
	 *
	 *	@return
	 *			La valeur d'un Zerb.
	 */
	public static int getValueOfZerb()
	{
		return Zerb.VALEUR_ZERB;
	}

	/**
	 *	Cette méthode permet de retourner l'id d'un Zerb.
	 *
	 *	@return
	 *			L'id d'un Zerb.
	 */
	public static int getIdOfZerb()
	{
		return Zerb.ID_ZERB;
	}

}