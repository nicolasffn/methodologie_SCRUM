import java.util.Scanner;

/**
 * 
 *
 */
public class InitialisationJeu
{
	private int nbrJoueurs;
	public static final int NBR_JOUEURS_MAX = 4;
	private Joueur tabJoueur[] = new Joueur[NBR_JOUEURS_MAX];
	
	/**
	 * <b>InitialisationJeu</b>
	 * 
	 */
	public InitialisationJeu()
	{
		System.out.println("============================================================");
		System.out.println("========================= INIT JEU =========================");
		System.out.println("============================================================");
		System.out.println("                             --                             ");
		System.out.println("============================================================");
		System.out.println("===================== CREATION JOUEURS =====================");
		System.out.println("============================================================");
		System.out.println("                             --                             ");
		System.out.println("");
		
		Scanner sc = new Scanner(System.in);
		System.out.print("** Combien de joueurs vont jouer ? [2-4] : ");
		this.nbrJoueurs = sc.nextInt();
		// puis on vide la ligne avant d'en lire une autre prochainement
		sc.nextLine();

			if(this.nbrJoueurs > 4) {
				System.err.println("Il ne peux pas y avoir plus de 4 joueurs !");
				System.exit(1);
			}
			
			System.out.println("                             --                             ");
			System.out.println("");

			for(int i = 0; i < this.nbrJoueurs; i++)
			{
				System.out.print("** Entrez le pseudo du joueur " + (i+1) + " : ");
				String nomJoueur = sc.nextLine();
				int idJoueur = i+1;
				this.tabJoueur[i] = new Joueur(nomJoueur, idJoueur);
				System.out.println("");
			}
			if(sc.nextLine() == null) {
				sc.close();
			}
			
			
			System.out.println("============================================================");
			System.out.println("=================== INIT PTS DES JOUEURS ===================");
			System.out.println("============================================================");
			System.out.println("                             --                             ");
			System.out.println("");
			
			for(int i = 0; i < this.nbrJoueurs; i++)
			{
				System.out.println("** " + this.tabJoueur[i].getNomJoueur() + " a " + this.tabJoueur[i].getPointsActionRestants() + " points d'actions.");
				System.out.println("");
			}
			
			new Jeu(this.nbrJoueurs, this.tabJoueur);

	}
}