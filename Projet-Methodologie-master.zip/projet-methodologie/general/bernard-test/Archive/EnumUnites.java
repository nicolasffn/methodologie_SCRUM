/**
 * 
 *
 */
public enum EnumUnites
{
    ZHERB, CRAPIT, KROGUL;
}
